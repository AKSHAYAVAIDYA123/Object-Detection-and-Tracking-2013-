clc; % Clear the previous data
close all; % Close the previous output
clear all;
[filename,pathname]=uigetfile({'*.avi;*.mp4'},'Input the file');
% Input the Video through dialog box
if ~exist((fullfile(pathname,filename))); % Check the existence of file
       morph;
    warndlg('Please select the Video','Warning')
break;
else
v=VideoReader(fullfile(pathname,filename)); 
% Store the Path name as a video object
n=get(v,'NumberOfFrames');
% Obtain the number of frames
for j=1:100
    img=read(v,j); % Read each and every frame
diff_im_red=imsubtract(img(:,:,1),rgb2gray(img));
%Subtract the red band of the image with the grayscale version of the image
diff_im_red=medfilt2(diff_im_red,[3,3]); % Remove the noise
diff_im_red=im2bw(diff_im_red,0.14); % Binarize the image with thresold value 0.14
diff_im_red=bwareaopen(diff_im_red,300); % Remove the objects less than 300 pixels
bw1=bwlabel(diff_im_red,8);
s1=regionprops(bw1,'BoundingBox','Centroid');
%Apply regionprops function to calculate centroid and apply bounding box
%for red objects

diff_im_green=imsubtract(img(:,:,2),rgb2gray(img));
%Subtract the green band of the image with the grayscale version of the image
diff_im_green=medfilt2(diff_im_green,[3,3]);% Remove the noise
diff_im_green=im2bw(diff_im_green,0.05); % Binarize the image with thresold value 0.05
diff_im_green=bwareaopen(diff_im_green,300);% Remove the objects less than 300 pixels
bw2=bwlabel(diff_im_green,8);
s2=regionprops(bw2,'BoundingBox','Centroid');
%Apply regionprops function to calculate centroid and apply bounding box
%for green objects

diff_im_blue=imsubtract(img(:,:,3),rgb2gray(img));
%Subtract the green band of the image with the grayscale version of the image
diff_im_blue=medfilt2(diff_im_blue,[3,3]);% Remove the noise
diff_im_blue=im2bw(diff_im_blue,0.05); % Binarize the image with thresold value 0.05
diff_im_blue=bwareaopen(diff_im_blue,300);% Remove the objects less than 300 pixels
bw3=bwlabel(diff_im_blue,8);
s3=regionprops(bw3,'BoundingBox','Centroid');
%Apply regionprops function to calculate centroid and apply bounding box
%for blue objects

figure(1),imshow(img);
hold on
for i=1:length(s1)
    bbr=s1(i).BoundingBox;
    bcr=s1(i).Centroid;
    rectangle('Position',bbr,'EdgeColor','r','LineWidth',2,'FaceColor','r');
    % Draw rectangle with red face color for red colored objects
 %   plot(bcr(1),bcr(2),'-m+');
%     a=text(bcr(1)+15,bcr(2),strcat('X:',num2str(round(bcr(1))),' Y:',num2str(round(bcr(2)))));
%     set(a,'FontName','Arial','FontWeight','bold','FontSize',12,'Color','black');
%     %Display the centroid values
end

for i=1:length(s2)
    bbg=s2(i).BoundingBox;
    bcg=s2(i).Centroid;
    rectangle('Position',bbg,'EdgeColor','g','LineWidth',2,'FaceColor','g');
%     % Draw rectangle with green face color for green colored objects
%     plot(bcg(1),bcg(2),'-m+');
%     b=text(bcg(1)+15,bcg(2),strcat('X:',num2str(round(bcg(1))),' Y:',num2str(round(bcg(2)))));
%     set(b,'FontName','Arial','FontWeight','bold','FontSize',12,'Color','black');
%     %Display the centroid values
end

for i=1:length(s3)
    bbb=s3(i).BoundingBox;
    bcb=s3(i).Centroid;
    rectangle('Position',bbb,'EdgeColor','b','LineWidth',2,'FaceColor','b');
%      % Draw rectangle with blue face color for blue colored objects
%     plot(bcb(1),bcb(2),'-m+');
%     c=text(bcb(1)+15,bcb(2),strcat('X:',num2str(round(bcb(1))),' Y:',num2str(round(bcb(2)))));
%     set(c,'FontName','Arial','FontWeight','bold','FontSize',12,'Color','black');
%     %Display the centroid values
end
hold off
end
end
close all;