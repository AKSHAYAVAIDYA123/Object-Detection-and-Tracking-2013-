clear all;
close all;
clc;
[filename,pathname]=uigetfile({'*.avi;*.mp4'},'Input the file');
if ~exist((fullfile(pathname,filename)));
break;
else
v=VideoReader(fullfile(pathname,filename));
n=get(v,'NumberOfFrames');
thr=8;
bg=read(v,1);
bg_bw=rgb2gray(bg);
fr_size=size(bg_bw);
height=fr_size(1);
width=fr_size(2);
fg=zeros(height,width);
for i=1:n
fr=read(v,i);
 fr_bw=rgb2gray(fr);
    fr_diff=abs(double(fr_bw)-double(bg_bw));
    for j=1:width
       for k=1:height
          if fr_diff(k,j)>thr
               fg(k,j)=255;
          else
               fg(k,j)=0;
          end
       end
    end
   fg=medfilt2(fg,[3,3]);
   fg=bwareaopen(fg,20);
     s=regionprops(fg,'BoundingBox','Centroid');
    figure(1),imshow(fr_bw);
    hold on;
    for l=1:length(s)
        bb=s(l).BoundingBox;
        bc=s(l).Centroid;
        rectangle('Position',bb,'EdgeColor','w','LineWidth',2);
        hold on;
    end
    hold off;
    bg_bw=fr_bw;
   %figure(1),imshow(uint8(fg)),title('binarized video');
end
end
close all;    



