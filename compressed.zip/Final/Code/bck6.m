clear all; %clears the previous data
close all; %closes the previous figure
clc;
[filename,pathname]=uigetfile({'*.avi;*.mp4'},'Input the file');  %uiget is used to get dialog box
if ~exist((fullfile(pathname,filename))); %check whether pathname is empty or not
    framediff;
    warndlg('Please select the Video','Warning')
 
break;
else
v=VideoReader(fullfile(pathname,filename)); %Store the pathname in a video object
n=get(v,'NumberOfFrames'); %Obtain the number of frames
thr=15;  % set threshold value
bg=read(v,1);  % Take first frame as background
bg_bw=rgb2gray(bg); % Convert it to grayscale
fr_size=size(bg_bw); % Obtain the width and height of a frame
height=fr_size(1);
width=fr_size(2);
fg=zeros(height,width);%Store the binarized frames in an array
for i=1:100
fr=read(v,i);  %read each and every frame iteratively
 fr_bw=rgb2gray(fr);
    fr_diff=abs(double(fr_bw)-double(bg_bw)); % Subtract two consecutive frames
    for j=1:width
       for k=1:height
          if fr_diff(k,j)>thr % if the difference is greater than threshold,motion is detected
               fg(k,j)=255;
          else
               fg(k,j)=0;% motion not detected.
          end
       end
    end
   fg=medfilt2(fg,[3,3]); %Remove the noise in the binarized image
   fg=bwareaopen(fg,30); % Remove small objects less than 30 pixels
     s=regionprops(fg,'BoundingBox','Centroid'); %Apply regionprops to determine centroids
    figure(1),imshow(fr_bw);
    hold on;
    for l=1:length(s)
        bb=s(l).BoundingBox;
        bc=s(l).Centroid;
        rectangle('Position',bb,'EdgeColor','w','LineWidth',2); %draw the bounding box around moving object
        hold on;
    end
    hold off;
    bg_bw=fr_bw; %reference frame becomes background frame
end
end
close all;