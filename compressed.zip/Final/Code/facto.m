function [] = facto(n)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
f=1;
for i=1:n
    f=f*i;
end
disp(f);
end

