[filename,pathname]=uigetfile({'*.avi;*.mp4'},'Input the file');  %uiget is used to get dialog box
if ~exist((fullfile(pathname,filename))); %check whether pathname is empty or not
    warndlg('Please select the Video','Warning')
break;
else
    msgbox('file read');
end 