[pathname,filename]=uigetfile({'*.jpg;*.png'},'Input an image');
v=imread(fullfile(filename,pathname));
for i=360:-10:0
    s=imrotate(v,i);
    figure(1);
    imshow(s);
    caption=sprintf('Angle=%d',i);
    title(caption);
    drawnow;
    pause(.5);
end