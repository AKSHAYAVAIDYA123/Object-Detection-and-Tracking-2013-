I = imread('board.tif');
J = rgb2gray(I);
figure, imshow(I), figure, imshow(J);

% [filename, pathname] = uigetfile('*', 'Select a MATLAB code file');
% if isequal(filename,0)
%    disp('User selected Cancel')
% else
%    disp(['User selected ', fullfile(pathname, filename)])
%    J = rgb2gray(filename);
%  figure, imshow(filename), figure, imshow(J);
% end