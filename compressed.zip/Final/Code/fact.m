N=input('Pick a number');
f=factorial(N);
%fprintf('the ',N);
%  fprintf('%g',f);
%  fprintf('\n');
%n = [0 1 2; 3 4 5];
%f = factorial(n);

fprintf('The Fibo sequence to %d terms is\n',N);
fprintf('%g',f);
fprintf('\n');