% Create video input object. 
vid = videoinput('winvideo',1);
% Set video input object properties for this Intellicam project.
set(vid,'TriggerRepeat',Inf);
vid.FrameGrabInterval = 5;
% Set value of a video source object property.
vid_src = getselectedsource(vid);
set(vid_src,'Tag','Intellicam setup');

% Create a figure window.
figure; 

% Start acquiring frames.
start(vid)
pause(2);
%pause helps the cam to adjust the lighting conditons
% Calculate difference image and display it.
while(vid.FramesAcquired<=100) % Stop after 1000 frames
    data = getdata(vid,2); 
    %Obtain the snapshots of a live video
    diff_im = imabsdiff(data(:,:,:,1),data(:,:,:,2));
    %Subtract two consecutive frames
    diff = rgb2gray(diff_im);
    % Convert the resultant image in grayscale
    diff_bw = im2bw(diff,0.2);
    %Binarize the resultant image with threshold value 0.2
    bw2 = imfill(diff_bw,'holes');
    s  = regionprops(bw2, 'centroid'); 
    %Apply regionprops to find centroids
    cd = s.Centroid;
    centroids = cat(1, s.Centroid);
    imshow(data(:,:,:,2));
    %imshow(diff_bw)
    hold(imgca,'on');
    plot(imgca,centroids(:,1),centroids(:,2),'g*'); 
    % Represent the centroids with green coloured asterix.It will be displayed
   hold on;
   hold(imgca,'off');
  
end
stop(vid)
close all;