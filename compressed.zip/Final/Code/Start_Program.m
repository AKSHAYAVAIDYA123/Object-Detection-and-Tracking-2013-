%%
x = menu('Compare_Images','Start Program','Exit')
if x == 1
    compare_images
else
    Project;
    break;
end