vid = videoinput('winvideo',1);
for i=1:2
    img=getsnapshot(vid);
    fname=['ABC' num2str(i)];
    imwrite(img,fname,'jpg');
    pause(2);
end