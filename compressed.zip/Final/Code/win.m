vid=videoinput('winvideo',1);
preview(vid);