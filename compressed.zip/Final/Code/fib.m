N=input('Pick a number');
fib1=zeros(1,N);
fib1(1)=1;
fib1(2)=1;
k=3;
while k<=N
    fib1(k)=fib1(k-2)+fib1(k-1);
    k=k+1;
end
fprintf('The Fibo sequence to %d terms is\n',N);
fprintf('%g',fib1);
fprintf('\n');
